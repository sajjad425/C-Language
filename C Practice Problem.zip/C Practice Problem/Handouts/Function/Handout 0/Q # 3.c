#include <stdio.h>

int avg(int , int , int );

int main()
{
    int num1, num2, num3, result;

    printf("Enter the  first number: ");
    scanf("%d", &num1);

    printf("\nEnter the  second number: ");
    scanf("%d", &num2);

    printf("\nEnter the  third number: ");
    scanf("%d", &num3);

    result = avg(num1, num2, num3);

    printf("\n%d\n", result);

    return 0;

}
int avg(int num1, int num2, int num3)
{
    return ((num1 + num2 + num3) / 3);
}

