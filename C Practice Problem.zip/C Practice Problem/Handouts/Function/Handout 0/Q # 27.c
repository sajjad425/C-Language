#include <stdio.h>

void alphabet(char );

void main()
{
    char alpha;

    printf("Enter an alphabet: ");
    scanf(" %c", &alpha);

    alphabet(alpha);

}

void alphabet(char alpha)
{
    if(alpha == 'a' || alpha == 'e' || alpha == 'i' || alpha == 'o' || alpha == 'u')
    {
        printf("\nVowel!\n");
    }
    else
    {
        printf("\nNot vowel!\n");
    }

}

