#include <stdio.h>

int main()
{
    int i, m, n;

    printf("Enter the number m: ");
    scanf("%d", &m);

    printf("\nEnter the number n: ");
    scanf("%d", &n);

    for(i = m; i <= n; i++)
    {
        printf("\n%d\n", i);
    }

    return 0;
}


