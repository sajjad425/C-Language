#include <stdio.h>

void num(int );

void main()
{
    int i;

    num(i);
}

void num(int i)
{
    int power = 1, a, b;

    printf("Enter the number a: ");
    scanf("%d", &a);

    printf("\nEnter the number b: ");
    scanf("%d", &b);

    for(i = 1; i <= b; i++)
    {

        power = power * a;
    }

    printf("\n%d\n", power);
}
