#include <stdio.h>

int main()
{
    int num, remainder, sum = 0;

    printf("Enter the number: ");
    scanf("%d", &num);

    if(num >= 0)
    {
        while(num > 0)
        {
            remainder = num % 10;

            sum = sum + remainder;

            num = num / 10;

        }

        printf("\nSum : %d\n", sum);
    }

    return 0;
}
