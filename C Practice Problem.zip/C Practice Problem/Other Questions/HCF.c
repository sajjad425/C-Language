#include <stdio.h>

int main()
{
    int i, num_1, num_2, hcf = 1, min;

    printf("Enter the first number: ");
    scanf("%d", &num_1);

    printf("Enter the second number: ");
    scanf("%d", &num_2);

    if(num_1 < num_2)
    {
        min = num_1;
    }
    else
    {
        min = num_2;
    }


    for(i = 1; i <= min; i++)
    {
        if(num_1 % i == 0)
        {
            if(num_2 % i == 0)
            {
               hcf = i;
            }
        }
    }
    {
        printf("The HCF of %d and %d is = %d", num_1, num_2, hcf);
    }

    return 0;

}
