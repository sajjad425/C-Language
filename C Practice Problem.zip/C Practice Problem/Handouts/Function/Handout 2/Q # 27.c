#include <stdio.h>

void num(int );

void main()
{
    int i;

    num(i);
}

void num(int i)
{
    int n, flag;

    printf("Enter the n number: ");
    scanf("%d", &n);

    for(i = 1; i <= n; i++)
    {

        if(n == i * i)
        {
           flag = 1;
        }
    }

    if (flag == 1)
    {
        printf("\nPerfect square\n");
    }
    else
    {
        printf("\nNot perfect square\n");
    }
}
