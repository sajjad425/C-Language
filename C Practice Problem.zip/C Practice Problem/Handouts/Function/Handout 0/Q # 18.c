#include <stdio.h>

int digit(int );

int main()
{
    int number, step1, step2, result;

    printf("Enter the number: ");
    scanf("%d", &number);

    result = digit(number);

    printf("\n%d\n", result);

    return 0;
}

int digit(int number)
{
    int step1, step2;

    step1 = number % 100;

    step2 = step1 % 10;

    return  step2;

}
