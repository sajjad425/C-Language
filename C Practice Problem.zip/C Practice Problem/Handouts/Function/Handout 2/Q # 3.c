#include <stdio.h>

void num(int );

void main()
{
    int number, i;

    num(number);
}

void num(int number)
{
    int i, n;

    printf("Enter the number n: ");
    scanf("%d", &n);

    for(i = 1; i <= n; i++)
    {
        printf("\nEnter the number: ");
        scanf("%d", &number);

        if(number > 0)
        {
            printf("\nPositive!\n");
        }
        else
        {
            printf("\nNegative!\n");
        }
    }
}


