#include <stdio.h>

void ascending(int , int );

void main()
{
    int number1, number2;

    printf("Enter the first number: ");
    scanf("%d", &number1);

    printf("\nEnter the second number: ");
    scanf("%d", &number2);

    ascending(number1, number2);
}

void ascending(int number1, int number2)
{
    if(number1 > number2)
    {
        printf("\n%d\n \n%d\n", number2, number1);
    }
    else
    {
        printf("\n%d\n \n%d\n", number1, number2);
    }
}



