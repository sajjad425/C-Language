#include <stdio.h>

int main()
{
    int i = 0, n, flag = 0;

    printf("Enter the number: ");
    scanf("%d", &n);

    while(i <= n)
    {

        if(n == i * i)
        {
           flag = 1;
        }

        i++;

    }

        if (flag == 1)
        {
            printf("Perfect square");
        }
        else
        {
            printf("Not perfect square");
        }

    return 0;
}
