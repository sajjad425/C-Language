#include <stdio.h>

void num(int );

void main()
{
    int i;

    num(i);
}

void num(int i)
{
    int n;

    printf("Enter the n number: ");
    scanf("%d", &n);

    for(i = 1; i <= 12; i++)
    {
        printf("\n%d * %d = %d\n", n, i, n * i);

    }
}

