#include <stdio.h>

int main()
{
    int num1, num2, num3;

    printf("Enter the number: ");
    scanf("%d", &num1);

    printf("Enter the number: ");
    scanf("%d", &num2);

    printf("Enter the number: ");
    scanf("%d", &num3);

    if(num1 > num2)
    {
        if(num1 > num3)
        {
            printf("First number is largest");

        }
        else
        {
            printf("Third numbr is largest");
        }
    }
    else
    {
        if(num2 > num3)
        {
            printf("Second number is largest");
        }
        else
        {
            printf("Third number is largest");
        }
    }

    return 0;
}
