//

#include <stdio.h>

int main()
{
    int a, x, i = 0;

    printf("Enter the number a: ");
    scanf("%d", &a);

    printf("Enter the number x: ");
    scanf("%d", &x);

    while(a >= x)
    {
        a = a - x;

        i++;
    }

    printf("%d", i);

    return 0;
}
