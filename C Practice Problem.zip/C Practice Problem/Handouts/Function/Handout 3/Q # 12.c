#include <stdio.h>

void add(int );

void main()
{
    int number;

    add(number);
}

void add(int number)
{
    int sum = 0;

    while(sum != 75 && sum < 75)
    {

        printf("\nEnter the number: ");
        scanf("\n%d", &number);

        sum = sum + number;
    }

    printf("\n%d\n", sum);
}
