#include <stdio.h>

int main()
{
    int ticket, sell, sum = 0;

    printf("Enter the no of tickets available: ");
    scanf("%d", &ticket);

    while(ticket != sum)
    {
        printf("Enter the no of ticket customer buys: ");
        scanf("%d", &sell);

        sum = sum + sell;
    }

    return 0;
}
