#include<stdio.h>

int main()
{
	int x, y;

	printf("Enter coordinates in the format (x,y): ");
	scanf("%d, %d", &x, &y);

	if(x == 0 && y == 0)
	{
		printf("\n x-axis \n y-axis\n");
	}
	else if(x == 0 && y != 0)
	{
		printf("\ny-axis\n");
	}
	else if(x != 0 && y == 0)
	{
		printf("\nx-axis\n");
	}
	else if(x > 0 && y > 0)
	{
		printf("First Quadrant");
	}
	else if(x < 0 && y > 0)
	{
		printf("Second Quadrant");
	}
	else if(x < 0 && y < 0)
	{
		printf("Third Quadrant");
	}
	else if(x > 0 && y < 0)
	{
		printf("Fourth Quadrant");
	}

	return 0;
}
