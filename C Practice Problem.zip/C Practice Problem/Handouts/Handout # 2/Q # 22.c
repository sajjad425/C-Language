#include <stdio.h>

int main()
{
    int i, m, n;

    printf("Enter the number m: ");
    scanf("%d", &m);

    printf("\nEnter the number n: ");
    scanf("%d", &n);

    for(i = 1; i <= m; i++)
    {
        printf("\n%d * %d = %d\n", n, i, n*i);
    }

    return 0;
}
