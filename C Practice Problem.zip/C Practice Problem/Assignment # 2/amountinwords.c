#include<stdio.h>

int main()
{
	int amount, unit, ten, hundred, thousand, ten1, hundred1;

	printf("Enter an amount (0 to 999999): ");
	scanf("%d", &amount);

	if(amount != 100000)
	{
		unit = amount % 10;
		amount = amount / 10;
		ten = amount % 10;
		amount = amount / 10;
		hundred = amount % 10;
		amount = amount / 10;
		thousand = amount % 10;
		amount = amount / 10;
		ten1 = amount % 10;
		amount = amount / 10;
		hundred1 = amount % 10;

		if(hundred1 != 0)
		{
			if(hundred1 == 1)
				printf("One Hundred and ");
			if(hundred1 == 2)
				printf("Two Hundred and ");
			if(hundred1 == 3)
				printf("Three Hundred and ");
			if(hundred1 == 4)
				printf("Four Hundred and ");
			if(hundred1 == 5)
				printf("Five Hundred and ");
			if(hundred1 == 6)
				printf("Six Hundred and ");
			if(hundred1 == 7)
				printf("Seven Hundred and ");
			if(hundred1 == 8)
				printf("Eight Hundred and ");
			if(hundred1 == 9)
				printf("Nine Hundred and ");
		}

		if(ten1 != 1)
		{
			if(ten1 != 0)
			{
				if(ten1 == 2)
					printf("Twenty ");
				if(ten1 == 3)
					printf("Thirty ");
				if(ten1 == 4)
					printf("Forty ");
				if(ten1 == 5)
					printf("Fivty ");
				if(ten1 == 6)
					printf("Sixty ");
				if(ten1 == 7)
					printf("Seventy ");
				if(ten1 == 8)
					printf("Eighty ");
				if(ten1 == 9)
					printf("Ninety ");
			}

		}


		if(thousand != 0)
		{
			if(thousand == 1)
				printf("One Thousand ");
			if(thousand == 2)
				printf("Two Thousand ");
			if(thousand == 3)
				printf("Three Thousand ");
			if(thousand == 4)
				printf("Four Thousand ");
			if(thousand == 5)
				printf("Five Thousand ");
			if(thousand == 6)
				printf("Six Thousand ");
			if(thousand == 7)
				printf("Seven Thousand ");
			if(thousand == 8)
				printf("Eight Thousand ");
			if(thousand == 9)
				printf("Nine Thousand ");
		}

		if(hundred != 0)
		{
			if(hundred == 1)
				printf("One Hundred and ");
			if(hundred == 2)
				printf("Two Hundred and ");
			if(hundred == 3)
				printf("Three Hundred and ");
			if(hundred == 4)
				printf("Four Hundred and ");
			if(hundred == 5)
				printf("Five Hundred and ");
			if(hundred == 6)
				printf("Six Hundred and ");
			if(hundred == 7)
				printf("Seven Hundred and ");
			if(hundred == 8)
				printf("Eight Hundred and ");
			if(hundred == 9)
				printf("Nine Hundred and ");
		}

		if(ten != 1)
		{
			if(ten != 0)
			{
				if(ten == 2)
					printf("Twoenty ");
				if(ten == 3)
					printf("Thirty ");
				if(ten == 4)
					printf("Forty ");
				if(ten == 5)
					printf("Fivty ");
				if(ten == 6)
					printf("Sixty ");
				if(ten == 7)
					printf("Seventy ");
				if(ten == 8)
					printf("Eighty ");
				if(ten == 9)
					printf("Ninety ");
			}

			if(unit != 0)
			{
				if(unit == 1)
					printf("One \n");
				if(unit == 2)
					printf("Two \n");
				if(unit == 3)
					printf("Three \n");
				if(unit == 4)
					printf("Four \n");
				if(unit == 5)
					printf("Five \n");
				if(unit == 6)
					printf("Six \n");
				if(unit == 7)
					printf("Seven \n");
				if(unit == 8)
					printf("Eight \n");
				if(unit == 9)
					printf("Nine \n");
			}
		}

		if(ten == 1)
        {
            if(ten == 0)
				printf("Ten \n");
			if(ten == 1)
				printf("Eleven \n");
			if(ten == 2)
				printf("Twelve \n");
			if(ten == 3)
				printf("Thirteen \n");
			if(ten == 4)
				printf("Forteen \n");
			if(ten == 5)
				printf("Fivteen \n");
			if(ten == 6)
				printf("Sixteen \n");
			if(ten == 7)
				printf("Seventeen \n");
			if(ten == 8)
				printf("Eighteen \n");
			if(ten == 9)
				printf("Nineteen \n");
		}
	}
	else{
		printf("Amount Invalid! ");
	}
	return 0;
}

