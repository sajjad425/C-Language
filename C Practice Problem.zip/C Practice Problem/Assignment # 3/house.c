#include<stdio.h>
int main(){

	int h, i, j;

	printf(" Please Enter Height of House : ");
	scanf( "%d",&h );

  // draw top of house
	for ( i=0; i<h; i++ ) {

		for ( j=0; j<h-i-1; j++ ) {
      		printf( " " );
    	}

		printf( "*" );

   		for ( j=0; j<i; j++ ) {
      		printf( "*" );
    	}

    	for ( j=0; j<i; j++ ) {
      		printf( "*" );
    	}

    	printf( "*" );

    	for ( j=0; j<h-i-1; j++ ) {
      		printf( " " );
    	}

    	printf( "\n" );
  	}	/* end of for i */

  	for( j=0; j<h*2; j++ ) {
    	printf( "*" );
  	}
  	printf( "\n" );

  // draw bottom of house
  	for ( i=0; i<h-1; i++ ) {
    	printf( "*" );

		for ( j=0; j<h*2-2; j++ ) {
    		printf( "*" );
    	}

		printf( "*\n" );
  }
  	for ( j=0; j<h*2; j++ ) {
    	printf( "*" );
  	}
  	printf( "\n" );

	return 0;
}

