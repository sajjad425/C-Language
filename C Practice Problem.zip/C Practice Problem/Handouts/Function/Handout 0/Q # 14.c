#include <stdio.h>

int convert(int );

int main()
{
    int memoryMB, result;

    printf("Enter the memory: ");
    scanf("%d", &memoryMB);

    result = convert(memoryMB);

    printf("\n%d\n", result);

    return 0;
}

int convert(int memoryMB)
{

    return  memoryMB * 1048576;

}
