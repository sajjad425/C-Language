#include <stdio.h>

void movie(int , int );

void main()
{
    int currentHour, currentMin, movieHour, movieMin, availableTicket, soldTicket;

    movie(availableTicket, soldTicket);
}

void movie(int availableTicket, int soldTicket)
{
    int currentHour, currentMin, movieHour, movieMin;

    printf("Enter the movie time(hh:mm): ");
    scanf("%d : %d", &movieHour, &movieMin);

    printf("\nEnter the current time(hh:mm): ");
    scanf("%d : %d", &currentHour, &currentMin);

    printf("\nEnter the avialable tickets: ");
    scanf("%d", &availableTicket);

    while(movieHour >= currentHour)
    {
        while(movieMin >= currentMin && movieMin != currentMin)
        {
            while(availableTicket != 0)
            {

                printf("\nEnter the number of ticket you want to buy: ");
                scanf("%d", &soldTicket);

                availableTicket = availableTicket - soldTicket;
            }

        }
    }
}
