#include <stdio.h>

int speed(float , float );

int main()
{
    float distanceKm, timeH, result;

    printf("Enter the distance : ");
    scanf("%f", &distanceKm);

    printf("\nEnter the Time : ");
    scanf("%f", &timeH);

    result = speed(distanceKm, timeH);

    printf("\nThe Speed is : %.2f\n", result);

    return 0;
}
int speed(float distanceKm, float timeH)
{

    return ((distanceKm * 1000) / (timeH * 3600));

}
