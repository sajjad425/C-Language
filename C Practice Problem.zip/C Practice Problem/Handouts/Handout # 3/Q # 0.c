#include <stdio.h>

int main()
{
    int num;

    while(num != 0)
    {
        printf("\nEnter the number: ");
        scanf("%d", &num);

        printf("\n%d\n", num);
    }

    return 0;
}
