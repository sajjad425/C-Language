#include <stdio.h>

void num(int );

void main()
{
    int i;

    num(i);
}

void num(int i)
{
    int n, m;

    printf("Enter the n number: ");
    scanf("%d", &n);

    printf("\nEnter the m number: ");
    scanf("%d", &m);

    for(i = 1; i <= m; i++)
    {
        printf("\n%d * %d = %d\n", n, i, n * i);

    }
}
