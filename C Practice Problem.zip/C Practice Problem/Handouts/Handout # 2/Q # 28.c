#include <stdio.h>

int main()
{
    int i, a, b, sum = 0;

    printf("Enter the number a: ");
    scanf("%d", &a);

    printf("Enter the number b: ");
    scanf("%d", &b);

    for(i = 1; i <= b; i++)
    {
        sum = sum + a;
    }

    printf("Product : %d", sum);

    return 0;
}
