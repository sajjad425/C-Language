#include <stdio.h>

void largest(int );

void main()
{
    int i;

    largest(i);
}

void largest(int i)
{
    int n, number, max = 0;

    printf("Enter the n number: ");
    scanf("%d", &n);

    for(i = 1; i <= n; i++)
    {
        printf("\nEnter the number: ");
        scanf("%d", &number);

        if(number > max)
        {
            max = number;
        }
    }

    printf("\n%d\n", max);
}
