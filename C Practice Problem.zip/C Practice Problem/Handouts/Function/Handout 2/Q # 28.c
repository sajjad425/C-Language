#include <stdio.h>

void num(int );

void main()
{
    int i;

    num(i);
}

void num(int i)
{
    int sum = 0, a, b;

    printf("Enter the number a: ");
    scanf("%d", &a);

    printf("\nEnter the number b: ");
    scanf("%d", &b);

    for(i = 1; i <= b; i++)
    {

        sum = sum + a;
    }

    printf("\n%d\n", sum);
}
