#include <stdio.h>

int swap(int , int );

int main()
{
    int num1, num2, num3;

    printf("Enter the first number: ");
    scanf("%d", &num1);

    printf("\nEnter the second number: ");
    scanf("%d", &num2);

    swap(num1, num2);

    printf("\nPrinting the values again to see whether they actually swaped or not:");
    printf("\n\nNumber#1: %d", num1);
    printf("\nNumber#2: %d\n", num2);

    printf("\nOh! They didn't actually swaped!\n");

    return 0;
}

int swap(int num1, int num2)
{
    int temp;

    temp    = num1;
    num1 = num2;
    num2 = temp;

    printf("\nAfter Swaping:");
    printf("\n\nNumber#1: %d", num1);
    printf("\nNumber#2: %d\n", num2);

    return 0;
}
