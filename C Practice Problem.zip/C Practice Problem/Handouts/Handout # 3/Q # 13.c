#include <stdio.h>

int main()
{
    int sum = 0, num, count = 0;

    while(sum < 75)
    {
        printf("Enter the number: ");
        scanf("%d", &num);

        sum = sum + num;

        count++;

    }
    printf("\n%d\n", count);





    return 0;
}
