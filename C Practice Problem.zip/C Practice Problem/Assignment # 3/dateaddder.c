#include<stdio.h>

int main ()
{
    int i, day, month, year;
    int monthdays;
    int addyears;
    int leftoverdays;
    int dd;


	printf("Enter the date (dd/mm/yyyy): ");
	scanf("%d/%d/%d", &day, &month, &year);

	printf("Enter the number of days : ");
	scanf("%d", &dd);


	addyears = dd / 365;
   	leftoverdays = dd % 365;

    if(month == 4 || month == 6 || month == 9 || month == 11)
	{
		monthdays = 30;
	}

    if(month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)
	{
        monthdays = 31;
	}

	if(month == 2)
	{
		if(year % 4 == 0)
    	{
        	if(year % 100 == 0)
        	{
            	if (year % 400 == 0)
				{
                	monthdays = 29;
                }
            	else
            	{
                	monthdays = 28;
                }
        	}
        	else
			{
            	monthdays = 29;
            }
    	}
    	else
		{
      		monthdays = 28;
		}
	}

    year += addyears;

    for (i = 0; i < leftoverdays; i++)
	{
		if (day < monthdays)
		{
            day ++;
        }
       	else if ((day == monthdays) && (month < 12))
        {
            day = 1;
            month ++;
        }
        else if ((day == monthdays) && (month == 12))
        {
            day = 1;
            month = 1;
            year ++;
        }
            else
			{
                printf("Incorrect Date! ");
            }
    }

	printf("New Date: %d/%d/%d ", day, month, year);

    return 0;
}
