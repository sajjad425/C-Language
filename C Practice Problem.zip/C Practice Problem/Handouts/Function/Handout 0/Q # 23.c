#include <stdio.h>

int num(int , int );

int main()
{
    int number1, number2;

    printf("Enter the first number: ");
    scanf("%d", &number1);

    printf("\nEnter the second number: ");
    scanf("%d", &number2);

    num(number1, number2);

    return 0;
}

int num(int number1, int number2)
{
    if(number1 < number2)
    {
        printf("\nThe first number is smaller .\n");
    }
    else
    {
        printf("\nThe second number is smaller.\n");
    }

    return 0;

}

