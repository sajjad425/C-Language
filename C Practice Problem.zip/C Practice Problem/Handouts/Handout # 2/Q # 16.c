
#include <stdio.h>

int main()
{
    int i, num, sum = 0;

    for(i = 1; i <= 10; i++)
    {
        printf("\nEnter the number: ");
        scanf("%d", &num);

        sum = sum + num;
    }

    printf("\nSum : %d\n", sum);

    return 0;
}

