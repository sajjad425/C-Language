#include <stdio.h>

int main()
{
    int num_1, num_2, num_3, num_4, sum = 0, difference = 0 , product = 0, division = 0, nume_1, deno_1, deno_2;

    printf("Enter the fractions: ");
    scanf("%d/%d,%d/%d", &num_1, &num_2, &num_3,&num_4);

    sum = (num_1 * num_4 + num_2 * num_3);
    deno_1 = (num_2 * num_4);

    difference = (num_1 * num_4 - num_2 * num_3);

    product = (num_1 * num_3);

    division = (num_1 * num_4);
    deno_2 = (num_2 * num_3);


    printf("sum: %d/%d \n", sum, deno_1);

    printf("difference: %d/%d \n", difference, deno_1);

    printf("product: %d/%d \n", product, deno_1);

    printf("division: %d/%d \n", division, deno_2);

    return 0;

}

