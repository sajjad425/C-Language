#include <stdio.h>

int main()
{
    int i, n, num, sum = 0, count = 0, avg = 0;

    printf("Enter the number n: ");
    scanf("%d", &n);

    for(i = 1; i <= n; i++)
    {
        printf("\nEnter the number: ");
        scanf("%d", &num);

        sum = sum + num;

        count++;

        avg = sum / count;
    }

    printf("\nAverage : %d\n", avg);

    return 0;
}

