#include <stdio.h>

int main()
{
    int angle1, angle2, angle3, sum = 0;

    printf("Enter the first angle: ");
    scanf("%d", &angle1);

    printf("\nEnter the second angle: ");
    scanf("%d", &angle2);

    printf("\nEnter the third angle: ");
    scanf("%d", &angle3);

    sum = angle1 + angle2 + angle3;

    if(sum == 180)
    {
        printf("\nValid Triangle\n");
    }
    else
    {
        printf("\nNot valid triangle\n");
    }

    return 0;
}
