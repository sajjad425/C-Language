#include <stdio.h>

int main()
{
    int i, n, num, positiveCount = 0;

    printf("Enter the n number: ");
    scanf("%d", &n);

    for(i = 0; i < n; i++)
    {
        printf("\nEnter the number: ");
        scanf("\n%d", &num);

        if(num > 0)
        {
            positiveCount++;
        }
    }
        printf("\nPositve : %d\n", positiveCount);

        return 0;
}



