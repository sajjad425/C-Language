#include <stdio.h>

void num(int );

void main()
{
    int n;

    num(n);
}

void num(int n)
{
    printf("Enter the number n: ");
    scanf("%d", &n);

    while(n >= 5)
    {
        n = n - 5;
    }

    if(n == 0)
    {
        printf("\nMultiple\n");
    }
    else
    {
        printf("\nNot multiple\n");
    }
}
