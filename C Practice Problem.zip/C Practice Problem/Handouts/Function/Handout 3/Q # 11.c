#include <stdio.h>

void grade(char );

void main()
{
    char alpha;

    grade(alpha);
}

void grade(char alpha)
{
    int count = 0;

    while(alpha != 'Z')
    {
        printf("\nEnter the grade: ");
        scanf(" %c", &alpha);

        if(alpha == 'A')
        {
            count++;
        }
    }

    printf("\n%d\n", count);

}
