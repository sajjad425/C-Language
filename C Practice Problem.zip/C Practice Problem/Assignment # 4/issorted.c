#include <stdio.h>

int main()
{
    int arr[5], i, count1 = 0, count2 = 0;

    for(i = 0; i <= 4; i++)
    {
        printf("Enter the number: ");
        scanf("%d", &arr[i]);
    }
    for(i = 0; i <= 4; i++)
    {
        if(arr[i] < arr[i + 1])
        {
            count1++;
        }
        else if(arr[i] > arr[i + 1])
        {
            count2++;
        }

    }
    if(count1 == 4)
    {
        printf("\nAscending Order\n");
    }
    else if(count2 == 4)
    {
        printf("\nDescending Order\n");
    }
    else
    {
        printf("\nNot Sorted\n");
    }

    return 0;
}
