#include <stdio.h>

void num(int );

void main()
{
    int i;

    num(i);
}

void num(int i)
{
    int n, sum = 0;

    printf("Enter the number n: ");
    scanf("%d", &n);

    for(i = 0; i <= n; i++)
    {
        sum = sum + i;
    }

    printf("\n%d\n", sum);
}
