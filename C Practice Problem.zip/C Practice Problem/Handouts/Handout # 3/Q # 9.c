#include <stdio.h>

int main()
{
    int i = 0, n, power = 1;

    printf("Enter the number: ");
    scanf("%d", &n);

    while(n > i)
    {
        power = power * 2;

        i++;
    }

    printf("%d", power);

    return 0;
}
