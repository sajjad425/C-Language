#include <stdio.h>

int main()
{
    int i, n, devision = 0, count = 0;

    printf("Enter the number n: ");
    scanf("%d", &n);

    for(i = 1; i <= n; i++)
    {
        devision = n % i;

        if(devision == 0)
        {
            count++;
        }
    }

    printf("\nCount : %d\n", count);

    return 0;
}
