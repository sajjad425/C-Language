#include <stdio.h>

void num(int );

void main()
{
    int i;

    num(i);
}

void num(int i)
{
    int n, count = 0;

    printf("Enter the n number: ");
    scanf("%d", &n);

    for(i = 1; i <= n; i++)
    {
        if(n % i == 0)
        {
            count++;
        }
    }

    printf("\nTotal factors: %d\n", count);
}
