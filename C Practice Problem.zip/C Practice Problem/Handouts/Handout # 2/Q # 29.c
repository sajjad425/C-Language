//Take two number input and find the power of the number.

#include <stdio.h>

int main()
{
    int i, num1, num2, power = 1;

    printf("Enter the number: ");
    scanf("%d", &num1);

    printf("Enter the Power: ");
    scanf("%d", &num2);

    for(i = 1; i <= num2; i++)
    {
        power = power * num1;
    }

    printf("Anwser : %d", power);

    return 0;
}
