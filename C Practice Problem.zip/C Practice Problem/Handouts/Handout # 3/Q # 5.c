#include <stdio.h>

int main()
{
    int a, i = 0;

    printf("Enter the number a: ");
    scanf("%d", &a);

    while(a >= 2)
    {
        a = a - 2;

        i++;
    }

    printf("%d", i);

    return 0;
}
