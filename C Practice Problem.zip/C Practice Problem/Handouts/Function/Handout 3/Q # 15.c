#include <stdio.h>

void add(int );

void main()
{
    int number;

    add(number );
}

void add(int number)
{
    int sum = 0;

    while(sum != 10000 && sum < 10000)
    {
        printf("\nEnter the donation amount: ");
        scanf("\n%d", &number);

        sum = sum + number;
    }

    printf("\n%d\n", sum);
}
