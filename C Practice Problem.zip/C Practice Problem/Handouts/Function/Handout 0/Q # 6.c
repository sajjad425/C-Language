#include <stdio.h>

int convert(int );

int main()
{
    int timeHour, result;

    printf("Enter the Time in Hour : ");
    scanf("%d", &timeHour);

    result = convert(timeHour);

    printf("\nThe Time in seconds is : %d\n", result);

    return 0;
}
int convert(int timeHour)
{
    return timeHour * 3600;
}
