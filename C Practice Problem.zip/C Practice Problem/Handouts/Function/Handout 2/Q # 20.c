#include <stdio.h>

void num(int );

void main()
{
    int i;

    num(i);
}

void num(int i)
{
    int n, num, num1, min = 0;

    printf("Enter the n number: ");
    scanf("%d", &n);

    printf("\nEnter the first number: ");
    scanf("%d", num1);

    for(i = 1; i <= n - 1; i++)
    {
        printf("\nEnter the number: ");
        scanf("%d", &num);

        if(num1 < num)
        {
            min = num1;
        }
        else
        {
            min = num;
        }

    }

    printf("\n%d\n", min);

    return 0;

}

