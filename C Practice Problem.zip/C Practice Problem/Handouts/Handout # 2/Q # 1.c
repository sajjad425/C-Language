#include <stdio.h>

int main()
{
    int i, num;

    for(i = 0; i < 10; i++)
    {
        printf("\nEnter the number: ");
        scanf("\n%d", &num);

        if(num > 0)
        {
            printf("\nPositive.\n");
        }
        else
        {
            printf("\nNot Positive.\n");
        }
    }

    return 0;
}

