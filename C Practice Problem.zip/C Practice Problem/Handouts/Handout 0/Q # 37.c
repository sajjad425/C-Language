#include <stdio.h>

int main()
{
    char player1, player2;

    printf("Rock:r , Paper:p , scissor:s\n");

    printf("Enter the player 1: ");
    scanf(" %c", &player1);

    printf("\nEnter the player 2: ");
    scanf(" %c", &player2);

    if(player1 == 'r')
    {
        if(player2 == 'p')
        {
            printf("\nPlayer 2 won.\n");
        }
        else if(player2 == 's')
        {
            printf("\nPlayer 1 won.\n");
        }
        else
        {
            printf("\nDraw!\n");
        }
    }
    else if(player1 == 'p')
    {
        if(player2 == 'r')
        {
            printf("\nPlayer 1 won.\n");
        }
        else if(player2 == 's')
        {
            printf("\nPlayer 2 won.\n");

        }
        else
        {
            printf("\nDraw.\n");
        }
    }
    else if(player1 == 's')
    {
        if(player2 == 'r')
        {
            printf("\nPlayer 2 won.\n");
        }
        else if(player2 == 'p')
        {
            printf("\nPlayer 1 won.\n");
        }
        else
        {
            printf("\nDraw!\n");
        }
    }
    else
    {
        printf("\nEnter the correct alphabet.\n");
    }



    return 0;
}
