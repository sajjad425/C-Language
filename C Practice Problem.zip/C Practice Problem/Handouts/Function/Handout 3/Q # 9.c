#include <stdio.h>

void num(int );

void main()
{
    int i = 0;

    num(i);
}

void num(int i)
{
    int n, power = 1;

    printf("Enter the number a: ");
    scanf("%d", &n);

    while(n > i)
    {
        power = power * 2;

        i++;
    }

    printf("\n%d\n", power);
}
