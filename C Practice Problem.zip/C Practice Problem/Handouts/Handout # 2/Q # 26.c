#include <stdio.h>

int main()
{
    int i, n, count = 0;

    printf("Enter the number n: ");
    scanf("%d", &n);

    for(i = 1; i <= n; i++)
    {
        if(n % i == 0)
        {
            count++;
        }
    }

    if(count == 2)
    {
        printf("\nn is a prime number\n");
    }
    else
    {
        printf("\nn is not a prime number\n");
    }

    return 0;
}
