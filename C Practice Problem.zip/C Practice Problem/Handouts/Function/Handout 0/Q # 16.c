#include <stdio.h>

int convert(float );

int main()
{
    float marks, result;

    printf("Enter the marks: ");
    scanf("%f", &marks);

    result = convert(marks);

    printf("\n%.2f\n", result);

    return 0;
}

int convert(float marks)
{

    return  (marks/15)*100;

}
