#include <stdio.h>

int speed(float , float );

int main()
{
    float distanceM, timeH, result;

    printf("Enter the distance : ");
    scanf("%f", &distanceM);

    printf("\nEnter the Time : ");
    scanf("%f", &timeH);

    result = speed(distanceM, timeH);

    printf("\nThe Speed is : %.2f\n", result);

    return 0;
}
int speed(float distanceM, float timeH)
{

    return ((distanceM / 1000) / timeH);

}
