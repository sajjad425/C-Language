#include <stdio.h>

void add();

void main()
{
    add();
}

void add()
{
    int i, n, sum = 0, number;

    printf("Enter the n number: ");
    scanf("%d", &n);

    for(i = 1; i <= n; i++)
    {
        printf("\nEnter the number: ");
        scanf("%d", &number);

        sum = sum + number;
    }

    printf("\n%d\n", sum);

}
