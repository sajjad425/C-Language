#include <stdio.h>

int main()
{
    int i = 0, power, result = 1, base;

    printf("Enter the power: ");
    scanf("%d", &power);

    printf("\nEnter the base: ");
    scanf("%d", &base);


    while(power > i)
    {
        result = result * base;

        i++;
    }

    printf("\n%d\n", result);

    return 0;
}
