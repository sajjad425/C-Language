#include <stdio.h>

int convert(int );

int main()
{
    int distanceKm, result;

    printf("Enter the distance in Km: ");
    scanf("%d", &distanceKm);

    result = convert(distanceKm);

    printf("\nThe distance in Meter is : %d\n", result);

    return 0;
}
int convert(int distanceKm)
{
    return distanceKm * 1000;
}
