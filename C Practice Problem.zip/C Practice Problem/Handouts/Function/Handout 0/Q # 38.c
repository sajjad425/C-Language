#include <stdio.h>

void sum(int );

void main()
{
    int add, number, i;

    sum(number);
}

void sum(int number)
{
    int add = 0, i;

    for(i = 1; i <= 5; i++)
    {
        printf("\nEnter the number: ");
        scanf("%d", &number);

        add = add + number;
    }

    printf("\n%d\n", add);
}
