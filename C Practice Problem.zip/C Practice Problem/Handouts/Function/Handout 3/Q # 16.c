#include <stdio.h>

void pf(int );

void main()
{
    int number;

    pf(number );
}

void pf(int number)
{
    int n, i = 0, flag;

    printf("Enter the number: ");
    scanf("%d", &n);

    while(i <= n)
    {
        if(n == i * i)
        {
           flag = 1;
        }

        i++;
    }

    if (flag == 1)
    {
        printf("\nPerfect square\n");
    }
    else
    {
        printf("\nNot perfect square\n");
    }
}
