#include <stdio.h>

int num(int );

int main()
{
    int number;

    printf("Enter the number: ");
    scanf("%d", &number);

    num(number);

    return 0;
}

int num(int number)
{
    if(number % 2 == 0)
    {
        printf("\nEven!\n");
    }
    else
    {
        printf("\nOdd!\n");
    }

    return 0;

}

