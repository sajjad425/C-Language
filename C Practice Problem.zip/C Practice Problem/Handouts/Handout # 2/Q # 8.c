#include <stdio.h>

int main()
{
    int i;

    for(i = 1; i <= 50; i++)
    {
        printf("\n%d\n", i);
    }

    return 0;
}
