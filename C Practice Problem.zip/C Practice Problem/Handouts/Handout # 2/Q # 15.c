#include <stdio.h>

int main()
{
    int i, m, n, sum = 0;

    printf("Enter the number m: ");
    scanf("%d", &m);

    printf("\nEnter the number n: ");
    scanf("%d", &n);

    for(i = m; i <= n; i++)
    {
        sum = sum + i;
    }

    printf("\nSum : %d\n", sum);

    return 0;
}

