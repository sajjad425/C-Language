#include <stdio.h>

int num(int );

int main()
{
    int number;

    printf("Enter the number: ");
    scanf("%d", &number);

    num(number);

    return 0;
}

int num(int number)
{
    if(number > 0)
    {
        printf("\nPositive\n");
    }
    else if(number < 0)
    {
        printf("\nNegative\n");
    }
    else
    {
        printf("\nZero\n");
    }

    return 0;

}
