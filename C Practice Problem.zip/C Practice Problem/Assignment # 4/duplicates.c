#include <stdio.h>

int main()
{
    int i, arr[5], count = 0;

    for(i = 0; i <= 4; i++)
    {
        printf("Enter the number: ");
        scanf("%d", &arr[i]);
    }

    for(i = 0; i <= 4; i++)
    {
        if(arr[i] == arr[i + 1])
        {
            count++;

        }
    }

    printf("%d" , count);

    return 0;
}
