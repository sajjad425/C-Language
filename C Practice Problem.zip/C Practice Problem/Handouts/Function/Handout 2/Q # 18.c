#include <stdio.h>

void average(int );

void main()
{
    int i;

    average(i);
}

void average(int i)
{
    int n, sum = 0, number, avg;

    printf("Enter the n number: ");
    scanf("%d", &n);

    for(i = 1; i <= n; i++)
    {
        printf("\nEnter the number: ");
        scanf("%d", &number);

        sum = sum + number;
    }

    avg = sum / n;

    printf("\n%d\n", avg);
}
