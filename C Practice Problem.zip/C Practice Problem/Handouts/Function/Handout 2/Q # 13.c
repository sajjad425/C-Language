#include <stdio.h>

void num(int );

void main()
{
    int i;

    num(i);
}

void num(int i)
{
    int m, n;

    printf("Enter the number m: ");
    scanf("%d", &m);

    printf("\nEnter the number n: ");
    scanf("%d", &n);

    for(i = m; i <= n; i++)
    {
        printf("\n%d\n", i);

    }
}
