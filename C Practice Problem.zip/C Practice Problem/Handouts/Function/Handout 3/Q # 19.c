#include <stdio.h>

void guess(int , int );

void main()
{
    int player1, player2;

    guess(player1, player2 );
}

void guess(int player1, int player2)
{
    int i, n;

    printf("Enter the number n: ");
    scanf("%d", &n);

    printf("Enter the number between 1 to 50(Player 1): ");
    scanf("%d", &player1);

    system("cls");

    for(i = 1; i <= n; i++)
    {
        printf("\nGuess the number: ");
        scanf("%d", &player2);

        if(player1 == player2)
        {
            break;
        }
    }
}
