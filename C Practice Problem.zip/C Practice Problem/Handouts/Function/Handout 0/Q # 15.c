#include <stdio.h>

int convert(int );

int main()
{
    int memoryGB, result;

    printf("Enter the memory: ");
    scanf("%d", &memoryGB);

    result = convert(memoryGB);

    printf("\n%d\n", result);

    return 0;
}

int convert(int memoryGB)
{

    return  memoryGB * 1073741824;

}
