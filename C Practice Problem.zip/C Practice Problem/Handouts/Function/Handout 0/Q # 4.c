#include <stdio.h>

int avg(int , int , int );

int main()
{
    int harisC, mohsinC, tayyabC, result;

    printf("Enter the number of chocolate Haris have: ");
    scanf("%d", &harisC);

    printf("\nEnter the number of chocolate Mohsin have: ");
    scanf("%d", &mohsinC);

    printf("\nEnter the number of chocolate Tayyab have: ");
    scanf("%d", &tayyabC);

    result = avg(harisC, mohsinC, tayyabC);

    printf("\n%d\n", result);

    return 0;

}
int avg(int harisC, int mohsinC, int tayyabC)
{
    return ((harisC + mohsinC + tayyabC) / 3);
}

