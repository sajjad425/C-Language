#include <stdio.h>

int main()
{
    int side1, side2, side3;

    printf("Enter the first side: ");
    scanf("%d", &side1);

    printf("\nEnter the first side: ");
    scanf("%d", &side1);

    printf("\nEnter the first side: ");
    scanf("%d", &side1);

    if(side1 + side2 > side3 || side1 + side3 > side2 || side2 + side3 > side1)
    {
        printf("\nValid\n");
    }
    else
    {
        printf("\nNot Valid\n");
    }

    return 0;
}
