#include <stdio.h>

int main()
{
    int a, b;

    printf("Enter a number: ");
    scanf("%d", &a);

    printf("Enter a number: ");
    scanf("%d", &b);

    while(a >= b)
    {
        a = a - b;
    }

    if(a == 0)
    {
        printf("Multiple");
    }
    else
    {
        printf("Not Multiple");
    }

    return 0;
}
