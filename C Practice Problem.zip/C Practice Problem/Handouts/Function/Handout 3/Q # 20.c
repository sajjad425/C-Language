#include <stdio.h>

void movie(int );

void main()
{
    int currentHour, currentMin, movieHour, movieMin, totalTicket;

    movie(totalTicket);
}

void movie(int totalTicket)
{
    int currentHour, currentMin, movieHour, movieMin;

    printf("Enter the movie time(hh:mm): ");
    scanf("%d : %d", &movieHour, &movieMin);

    printf("\nEnter the current time(hh:mm): ");
    scanf("%d : %d", &currentHour, &currentMin);

    while(movieHour >= currentHour)
    {
        while(movieMin >= currentMin && movieMin != currentHour)
        {
            printf("\nEnter the num of ticket: ");
            scanf("%d", &totalTicket);
        }
    }
}
