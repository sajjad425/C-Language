#include <stdio.h>

int main()
{
    int day, month, year, time, hour, minute, digit_1, digit_2, digit_3, digit_4, temp_1, temp_2,digit_5, digit_6, digit_7, digit_8, temp_3, temp_4;

    printf("Enter the date and time: ");
    scanf("%d / %d / %d %d", &day, &month, &year, &time);

    digit_1 = time / 1000;
    temp_1 = time % 1000;
    digit_2 = temp_1 / 100;

    hour = digit_1 * 10 + digit_2;

    temp_2 = temp_1 % 100;
    digit_3 = temp_2 / 10;
    digit_4 = temp_2 % 10;

    minute = digit_3 * 10 + digit_4;

    digit_5 = year % 1000;
    digit_6 = digit_5 % 100;
    digit_7 = digit_6 / 10;
    digit_8 = digit_6 % 10;

    year = digit_7 * 10 + digit_8;

    printf("%d : %d - %d / %d / %d", hour, minute, month, day, year);


    return 0;
}
