#include <stdio.h>

int main()
{
    int a;

    printf("Enter a number: ");
    scanf("%d", &a);

    while(a >= 5)
    {
        a = a - 5;
    }

    if(a == 0)
    {
        printf("Multiple");
    }
    else
    {
        printf("Not Multiple");
    }

    return 0;
}
