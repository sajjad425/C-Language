#include <stdio.h>

int main()
{
    char alpha;

    printf("Enter an alphabet: ");
    scanf(" %c", &alpha);

    if(alpha == 'a' || alpha == 'e' || alpha == 'i' || alpha == 'o' || alpha == 'u')
    {
        printf("\nVowel\n");
    }
    else
    {
        printf("\nConsonant\n");
    }

    return 0;
}
