#include <stdio.h>

int convert(int );

int main()
{
    int tempF, result;

    printf("Enter the temperature: ");
    scanf("%d", &tempF);

    result = convert(tempF);

    printf("\n%d\n", result);

    return 0;
}

int convert(int tempF)
{

    return (5*(tempF - 32))/9;

}
