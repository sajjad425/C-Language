#include <stdio.h>

int main()
{
    int player1, player2, i = 0;

    printf("Enter the number between 1 to 50(player 1): ");
    scanf("%d", &player1);

    while(i <= 5)
    {
        i++;

        while(player1 != player2)
        {
            printf("Guess the number: ");
            scanf("%d", &player2);



        }



    }

    return 0;

}
