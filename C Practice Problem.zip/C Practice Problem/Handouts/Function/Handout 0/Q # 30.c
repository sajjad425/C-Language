#include <stdio.h>

void largest(int , int , int );

void main()
{
    int number1, number2, number3;

    printf("Enter the first number: ");
    scanf("%d", &number1);

    printf("\nEnter the second number: ");
    scanf("%d", &number2);

    printf("\nEnter the third number: ");
    scanf("%d", &number3);

    largest(number1, number2, number3);
}

void largest(int number1, int number2, int number3)
{
    if(number1 < number2)
    {
        if(number1 < number3)
        {
            printf("\nFirst number is smallest.\n");

        }
        else
        {
            printf("\nThird number is smallest.\n");
        }
    }
    else
    {
        if(number2 < number3)
        {
            printf("\nSecond number is smallest.\n");
        }
        else
        {
            printf("\nThird number is smallest.\n");
        }
    }
}



