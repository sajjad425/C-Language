//Counting How many number are positive, negative and zero.

#include <stdio.h>

int main()
{
    int i, n, num, positiveCount = 0, negativeCount = 0, zeroCount = 0;

    printf("Enter the n number: ");
    scanf("%d", &n);

    for(i = 0; i < n; i++)
    {
        printf("\nEnter the number: ");
        scanf("\n%d", &num);

        if(num > 0)
        {
            positiveCount++;
        }
        else if(num < 0)
        {
            negativeCount++;
        }
        else
        {
            zeroCount++;
        }

    }
        printf("\nPositve : %d\n", positiveCount);

        printf("\nNegative : %d\n", negativeCount);

        printf("\nZero : %d\n", zeroCount);

        return 0;
}



