#include <stdio.h>

void side(int , int , int , int );

void main()
{
    int side1, side2, side3, side4;

    printf("Enter the first side: ");
    scanf("%d", &side1);

    printf("\nEnter the second side: ");
    scanf("%d", &side2);

    printf("\nEnter the third side: ");
    scanf("%d", &side3);

    printf("\nEnter the fourth side: ");
    scanf("%d", &side4);

    side(side1, side2, side3, side4);
}

void side(int side1, int side2, int side3, int side4)
{
    if(side1 ==  side3 && side2 == side4)
    {
        printf("\nValid rectangle\n");
    }
    else
    {
        printf("\nNot valid rectangle\n");
    }
}



