#include <stdio.h>

void angle(int , int , int );

void main()
{
    int angle1, angle2, angle3;

    printf("Enter the first angle: ");
    scanf("%d", &angle1);

    printf("\nEnter the second angle: ");
    scanf("%d", &angle2);

    printf("\nEnter the third angle: ");
    scanf("%d", &angle3);

    angle(angle1, angle2, angle3);
}

void angle(int angle1, int angle2, int angle3)
{
    if(angle1 + angle2 + angle3 == 180)
    {
        printf("\nValid triangle\n");
    }
    else
    {
        printf("\nNot valid triangle\n");
    }
}



