#include <stdio.h>

void num(int , int );

void main()
{
    int n, x;

    num(n, x);
}

void num(int n, int x)
{

    printf("Enter the n number: ");
    scanf("%d", &n);

    printf("\nEnter the x number: ");
    scanf("%d", &x);

    while(n >= x)
    {
        n = n - x;
    }

    if(n == 0)
    {
        printf("\nMultiple\n");
    }
    else
    {
        printf("\nNot multiple\n");
    }
}
