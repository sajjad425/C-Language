#include <stdio.h>

int digit(int );

int main()
{
    int number, result;

    printf("Enter the number: ");
    scanf("%d", &number);

    result = digit(number);

    printf("\n%d\n", result);

    return 0;
}

int digit(int number)
{

    return  number/100;

}
