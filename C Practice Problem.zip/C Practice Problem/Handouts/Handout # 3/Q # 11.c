#include <stdio.h>

int main()
{
    char letter;
    int count = 0;

    while(letter != 'Z')
    {
        printf("Enter the letter: ");
        scanf("\n%c" , &letter);

        if(letter == 'A')
        {
            count++;
        }
    }

    printf("\n%d\n", count);

    return 0;
}
