#include <stdio.h>

void movie(int );

void main()
{
    int availableTicket, soldTicket;

    movie(soldTicket);
}

void movie(int soldTicket)
{
    int availableTicket;

    printf("Enter the avialable tickets: ");
    scanf("%d", &availableTicket);

    while(availableTicket != 0)
    {
        printf("\nEnter the number of ticket you want to buy: ");
        scanf("%d", &soldTicket);

        availableTicket = availableTicket - soldTicket;
    }
}
