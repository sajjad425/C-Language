#include <stdio.h>

int main()
{
    int num;

    while(num != 0)
    {
        printf("\nEnter the number: ");
        scanf("%d", &num);

        if(num % 2 == 0)
        {
            printf("\nEven\n");
        }
        else
        {
            printf("\nOdd\n");
        }
    }

    return 0;
}
