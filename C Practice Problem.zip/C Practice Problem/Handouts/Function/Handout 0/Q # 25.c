#include <stdio.h>

int num(int );

int main()
{
    int number;

    printf("Enter the number: ");
    scanf("%d", &number);

    num(number);

    return 0;
}

int num(int number)
{
    if(number % 5 == 0)
    {
        printf("\nDivisible!\n");
    }
    else
    {
        printf("\nNot divisible!\n");
    }

    return 0;

}

