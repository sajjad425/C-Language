//Find Out weather the number is positive negative or zero.

#include <stdio.h>

int main()
{
    int number;

    printf("Enter the number: ");
    scanf("%d", &number);

    if(number > 0)
    {
        printf("Positive");
    }
    else if(number < 0)
    {
        printf("Negative");
    }
    else
    {
        printf("Zero");
    }

    return 0;
}
