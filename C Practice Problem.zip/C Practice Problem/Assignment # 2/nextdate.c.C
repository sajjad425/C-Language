#include <stdio.h>

int main ()
{
    int day, month, year, monthdays;

	printf("Enter the date: ");
	scanf("%d/%d/%d", &day, &month, &year);

    if(month == 4 || month == 6 || month == 9 || month == 11)
	{
		monthdays = 30;
	}

    if(month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)
	{
        monthdays = 31;
	}

	if(month == 2)
	{
		if(year % 4 == 0)
    	{
        	if(year % 100 == 0)
        	{
            	if (year % 400 == 0)
				{
                	monthdays = 29;
                }
            	else
            	{
                	monthdays = 28;
                }
        	}
        	else
			{
            	monthdays = 29;
            }
    	}
    	else
		{
      		monthdays = 28;
		}
	}

    if(day < monthdays)
	{
        day++;

        printf("\nNext day date: %d/%d/%d\n", day, month, year);
    }
    else if(day == monthdays && month < 12)
    {
        day = 1;
        month ++;

        printf("\nNext day date: %d/%d/%d\n", day, month, year);
    }
    else if(day == monthdays && month == 12)
    {
        day = 1;
        month = 1;
        year ++;

        printf("\nNext day date: %d/%d/%d\n", day, month, year);
    }

    return 0;
}
