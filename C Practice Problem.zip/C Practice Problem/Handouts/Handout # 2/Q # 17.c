#include <stdio.h>

int main()
{
    int i, n, num, sum = 0;

    printf("Enter the number n: ");
    scanf("%d", &n);

    for(i = 1; i <= n; i++)
    {
        printf("\nEnter the number: ");
        scanf("%d", &num);

        sum = sum + num;
    }

    printf("\nSum : %d\n", sum);

    return 0;
}

