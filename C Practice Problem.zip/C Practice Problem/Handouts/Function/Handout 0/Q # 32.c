#include <stdio.h>

main()
{
   int num1, num2, num3, temp1, temp2, temp3;

   printf("Enter the first number: ");
   scanf("%d", &num1);

   printf("\nEnter the second number: ");
   scanf("%d", &num2);

   printf("\nEnter the third number: ");
   scanf("%d", &num3);

    if(num1 > num2)
    {
        temp2 = num1;

        temp3 = num2;
    }
    else
    {
        temp2 = num2;

        temp3 = num1;
    }
    if(temp2 > num3)
    {
      temp1 = temp2;

        if(temp3 > num3)
        {
            temp2 = temp3;

            temp3 = num3;
        }
        else
        {
            temp2 = num3;
        }
    }
   else
    {
            temp1 = num3;
    }

    printf("\n%d\n", temp3);

    printf("\n%d\n", temp2);

    printf("\n%d\n", temp1);
}
