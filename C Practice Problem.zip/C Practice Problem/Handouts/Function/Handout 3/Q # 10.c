#include <stdio.h>

void num(int );

void main()
{
    int i = 0;

    num(i);
}

void num(int i)
{
    int n, x, power = 1;

    printf("Enter the number x: ");
    scanf("%d", &x);

    printf("\nEnter the number n: ");
    scanf("%d", &n);

    while(n > i)
    {
        power = power * x;

        i++;
    }

    printf("\n%d\n", power);
}
