#include <stdio.h>

int main()
{
    int i, num, digit_1, digit_2, sum, flag;

    printf("Enter the number: ");
    scanf("%d", &num);

    digit_1 = num / 10;

    digit_2 = num % 10;

    sum = digit_1 + digit_2;

    for(i = 1; i <= sum; i++)
    {
        if(sum == i * i)
        {
            flag = 1;
            break;
        }
    }
    if (flag == 1)
    {
        printf("YES, sum is %d which is perfect square of %d", sum, i);
    }
    else
    {
        printf("NO, sum is %d which is not perfect square", sum);
    }

    return 0;
}
