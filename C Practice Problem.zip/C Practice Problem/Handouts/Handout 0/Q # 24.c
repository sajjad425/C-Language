#include <stdio.h>

int main()
{
    int number;

    printf("Enter the number: ");
    scanf("%d", &number);

    if(number % 2 == 0)
    {
        printf("\nEven\n");
    }
    else
    {
        printf("\nOdd\n");
    }

    return 0;
}
