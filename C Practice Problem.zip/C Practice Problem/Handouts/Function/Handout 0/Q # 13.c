#include <stdio.h>

int convert(int );

int main()
{
    int memoryKB, result;

    printf("Enter the memory: ");
    scanf("%d", &memoryKB);

    result = convert(memoryKB);

    printf("\n%d\n", result);

    return 0;
}

int convert(int memoryKB)
{

    return  memoryKB * 1024;

}
