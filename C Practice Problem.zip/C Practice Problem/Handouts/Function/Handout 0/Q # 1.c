#include <stdio.h>

int avg(int , int );

int main()
{
    int num1, num2, result;

    printf("Enter the  first number: ");
    scanf("%d", &num1);

    printf("\nEnter the  second number: ");
    scanf("%d", &num2);

    result = avg(num1, num2);

    printf("\n%d\n", result);

    return 0;

}
int avg(int num1, int num2)
{
    return ((num1 + num2) / 2);
}

