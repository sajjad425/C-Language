#include <stdio.h>

void num(int );

void main()
{
    int i;

    num(i);
}

void num(int i)
{
    int n, count = 0, division;

    printf("Enter the n number: ");
    scanf("%d", &n);

    for(i = 2; i <= n - 1; i++)
    {
        if(n % i == 0)
        {
            count++;
        }
    }

    printf("\n%d\n", count);
}
