#include <stdio.h>

int main()

{
    int num, sentinal_value;

    printf("Enter the sentinal value: ");
    scanf("%d", &sentinal_value);

    while(num != sentinal_value)
    {
        printf("\nEnter the number: ");
        scanf("%d", &num);

        if(num % 2 == 0)
        {
            printf("\nEven\n");
        }
        else
        {
            printf("\nOdd\n");
        }
    }

    return 0;
}
