#include <stdio.h>

int main()
{
    int totalBill, customerPays, difference, note_1000, note_500, note_100, note_50, note_10, note_5, note_2, note_1;
    int temp_1, temp_2, temp_3, temp_4,temp_5, temp_6, temp_7, totalNotes;

    printf("Enter the total bill: ");
    scanf("%d", &totalBill);

    printf("\nEnter the customer pays: ");
    scanf("%d", &customerPays);

    difference = customerPays - totalBill;

    note_1000 = difference / 1000;

    temp_1 = difference % 1000;

    note_500 = temp_1 / 500;

    temp_2 = temp_1 % 500;

    note_100 = temp_2 / 100;

    temp_3 = temp_2 % 100;

    note_50 = temp_3 / 50;

    temp_4 = temp_3 % 50;

    note_10 = temp_4 / 10;

    temp_5 = temp_4 % 10;

    note_5 = temp_5 / 5;

    temp_6 = temp_5 % 5;

    note_2 = temp_6 / 2;

    temp_7 = temp_6 % 2;

    note_1 = temp_7 / 1;


    totalNotes = note_1 + note_2 + note_5 + note_10 + note_50 + note_100 + note_500 + note_1000;

    printf("\nRs. 1 Notes: %d\n", note_1);

    printf("Rs. 2 Notes: %d\n", note_2);

    printf("Rs. 5 Notes: %d\n", note_5);

    printf("Rs. 10 Notes: %d\n", note_10);

    printf("Rs. 50 Notes: %d\n", note_50);

    printf("Rs. 100 Notes: %d\n", note_100);

    printf("Rs. 500 Notes: %d\n", note_500);

    printf("Rs. 1000 Notes: %d\n", note_1000);

    printf("Total number of rupee Notes: %d\n", totalNotes);

    return 0;

}
