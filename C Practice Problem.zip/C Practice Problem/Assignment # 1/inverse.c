#include <stdio.h>

int main()
{
    int num_1, num_2, num_3, multiply = 0;

    printf("Enter the fraction: ");
    scanf("%d %d/%d", &num_1, &num_2, &num_3);

    multiply = num_1 * num_3 + num_2;

    printf("%d / %d", num_3,multiply);

    return 0;

}
