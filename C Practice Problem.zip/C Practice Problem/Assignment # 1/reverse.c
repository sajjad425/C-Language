#include <stdio.h>

int main()
{
    int num, digit_1, digit_2, digit_3, digit_4, temp_1, temp_2, reverse;

    printf("Enter the number: ");
    scanf("%d", &num);

    digit_1 = num / 1000;

    temp_1 = num % 1000;

    digit_2 = temp_1 / 100;

    temp_2 = temp_1 % 100;

    digit_3 = temp_2 / 10;

    digit_4 = temp_2 % 10;

    reverse = digit_4 * 1000 + digit_3 * 100 + digit_2 * 10 + digit_1;

    printf("\n%d\n", reverse);

    return 0;
}
