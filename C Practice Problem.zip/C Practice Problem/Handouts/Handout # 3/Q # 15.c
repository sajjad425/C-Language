#include <stdio.h>

int main()
{
    char name;
    int amount = 0, num;


    while(amount != 10000)
    {
        printf("Your name first letter: ");
        scanf("\n%c" , &name);

        printf("Enter the donation amount: ");
        scanf("%d", &num);

        amount = amount + num;
    }

    printf("%d", amount);

    return 0;
}
