#include <stdio.h>

void side(int , int , int );

void main()
{
    int side1, side2, side3;

    printf("Enter the first side: ");
    scanf("%d", &side1);

    printf("\nEnter the second side: ");
    scanf("%d", &side2);

    printf("\nEnter the third side: ");
    scanf("%d", &side3);

    side(side1, side2, side3);
}

void side(int side1, int side2, int side3)
{
    if(side1 + side2 > side3 && side2 + side3 > side1 && side1 + side3 > side2)
    {
        printf("\nValid triangle\n");
    }
    else
    {
        printf("\nNot valid triangle\n");
    }
}



