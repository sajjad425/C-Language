#include <stdio.h>

void num(int );

void main()
{
    int age;

    printf("Enter your age: ");
    scanf("%d", &age);

    num(age);
}

void num(int age)
{
    if(age < 16)
    {
        printf("\nYou can't drive.\n");
    }
    else if(age < 18)
    {
        printf("\nYou can't Vote.\n");
    }
    else if(age < 25)
    {
        printf("\nYou can't rent a car.\n");
    }
    else if(age >= 25)
    {
        printf("\nYou can do anything that legal.\n");
    }
    else
    {
        printf("\nEnter the correct age.\n");
    }

}


