#include <stdio.h>

void num(int );

void main()
{
    int i;

    num(i);
}

void num(int i)
{
    for(i = 1; i <= 100; i++)
    {
        printf("\n%d\n", i);

    }
}
