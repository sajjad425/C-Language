#include <stdio.h>
int main()
{
    int x, y, i, flag;

    printf(" Enter X : ");
    scanf("%d",&x);

    printf(" Enter Y : ");
    scanf("%d",&y);

    while (x < y)
    {
        flag = 0;

        for(i = 2; i <= x/2; ++i)
        {
            if(x % i == 0)
            {
                flag = 1;
                break;
            }
        }

        if (flag == 0)
            printf("%d ", x);

        ++x;
    }

    return 0;
}
