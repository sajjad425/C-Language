#include <stdio.h>

int convert(int );

int main()
{
    int tempC, result;

    printf("Enter the temperature: ");
    scanf("%d", &tempC);

    result = convert(tempC);

    printf("\n%d\n", result);

    return 0;
}

int convert(int tempC)
{
    return tempC + 273;

}
