#include <stdio.h>

int main()
{
    int sum = 0, num;

    while(sum < 75)
    {
        printf("Enter the number: ");
        scanf("%d", &num);

        sum = sum + num;
    }

    printf("%d", sum);

    return 0;
}
