#include <stdio.h>

int main()
{
    int length1, length2, length3, length4;

    printf("Enter the first length: ");
    scanf("%d", &length1);

    printf("\nEnter the second length: ");
    scanf("%d", &length2);

    printf("\nEnter the third length: ");
    scanf("%d", &length3);

    printf("\nEnter the fourth length: ");
    scanf("%d", &length4);


    if(length1 == length2 && length1 == length3 && length1 == length4 && length2 == length3 && length2 == length4)
    {
        printf("\nValid\n");
    }
    else
    {
        printf("\nNot valid\n");
    }

    return 0;
}
