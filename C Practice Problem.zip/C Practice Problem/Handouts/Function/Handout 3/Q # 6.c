#include <stdio.h>

void num(int , int );

void main()
{
    int a, x;

    num(a, x);
}

void num(int a, int x)
{
    int i = 0;

    printf("Enter the number a: ");
    scanf("%d", &a);

    printf("\nEnter the number x: ");
    scanf("%d", &x);

    while(a >= x)
    {
        a = a - x;

        i++;

    }

    printf("\n%d\n", i);
}
