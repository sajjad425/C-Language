#include <stdio.h>

void num(int );

void main()
{
    int number;

    num(number);
}

void num(int number)
{

    while(number != 0)
    {
        printf("\nEnter the number: ");
        scanf("%d", &number);

        printf("\n%d\n", number * number);

    }
}
