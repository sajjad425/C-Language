#include <stdio.h>

void num(int );

void main()
{
    int number;

    num(number);
}

void num(int number)
{
    int i = 0;

    printf("Enter the number: ");
    scanf("%d", &number);

    while(number >= 2)
    {
        number = number - 2;

        i++;
    }

    printf("\n%d\n", i);
}
