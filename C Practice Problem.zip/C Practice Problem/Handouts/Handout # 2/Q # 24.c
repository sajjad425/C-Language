#include <stdio.h>

int main()
{
    int i, n, n1 = 0, devision = 0, count = 0;

    printf("Enter the number n: ");
    scanf("%d", &n);

    for(i = 2; i <= n; i++)
    {
        n1 = n - 1;

        devision = n1 % i;

        if(devision == 0)
        {
            count++;
        }
    }

    printf("\nCount : %d\n", count);

    return 0;
}
