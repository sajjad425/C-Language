#include <stdio.h>

void num(int );

void main()
{
    int number;

    num(number);
}

void num(int number)
{

    while(number != 0)
    {
        printf("\nEnter the number: ");
        scanf("%d", &number);

        if(number > 0)
        {
            printf("\nPositive\n");
        }
        else
        {
            printf("\nNegative\n");
        }
    }
}
