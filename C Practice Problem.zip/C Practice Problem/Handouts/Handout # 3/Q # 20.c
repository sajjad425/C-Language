#include <stdio.h>

int main()
{
    int currentHour, currentMin, movieHour, movieMin, totalTicket;

    printf("Enter the movie time(hh:mm):  ");
    scanf("%d:%d", &movieHour, &movieMin);

    printf("Enter the current time(hh:mm): ");
    scanf("%d:%d", &currentHour, &currentMin);

    while(movieHour >= currentHour)
    {
        while(movieMin >= currentMin)
        {
            printf("Enter the num of ticket: ");
            scanf("%d", &totalTicket);
        }

    }

    return 0;
}
