#include <stdio.h>

void add(int );

void main()
{
    int i;

    add(i);
}

void add(int i)
{
    int n, sum = 0, number;

    for(i = 1; i <= 10; i++)
    {
        printf("\nEnter the number: ");
        scanf("%d", &number);

        sum = sum + number;
    }

    printf("\n%d\n", sum);
}
