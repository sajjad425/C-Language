#include <stdio.h>

int convert(int , int );

int main()
{
    int distanceKm, timeHour,  result;

    printf("Enter the distance: ");
    scanf("%d", &distanceKm);

    printf("Enter the Time: ");
    scanf("%d", &timeHour);

    result = convert(distanceKm, timeHour);

    printf("\nThe Speed is : %d\n", result);

    return 0;
}
int convert(int distanceKm, int timeHour)
{
    return (distanceKm / timeHour);
}
