#include <stdio.h>

int main()
{
    int i, n, num;

    printf("Enter the n number: ");
    scanf("%d", &n);

    for(i = 0; i < n; i++)
    {
        printf("\nEnter the number: ");
        scanf("\n%d", &num);

        if(num > 0)
        {
            printf("\nPositive.\n");
        }
        else
        {
            printf("\nNot Positive.\n");
        }
    }

    return 0;
}


