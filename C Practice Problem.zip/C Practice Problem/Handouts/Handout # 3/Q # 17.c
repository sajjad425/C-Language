#include <stdio.h>
#include <conio.h>

int main()
{
    int player1, player2;

    printf("Enter the number between 1 to 50(Player 1): ");
    scanf("%d", &player1);

    system("cls");

    while(player1 != player2)
    {
        printf("Guess the number: ");
        scanf("%d", &player2);

    }

    return 0;

}
