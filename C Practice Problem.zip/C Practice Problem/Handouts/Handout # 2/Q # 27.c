#include <stdio.h>

int main()
{
    int i, n, flag = 0;

    printf("Enter the number: ");
    scanf("%d", &n);

    for(i = 0; i <= n; i++)
    {

        if(n == i * i)
        {
           flag = 1;
        }

    }

        if (flag == 1)
        {
            printf("perfect square");
        }
        else
        {
            printf("Not perfect square");
        }

    return 0;
}
